import { useState,useEffect } from 'react';
import './App.css';
import Editor from "@monaco-editor/react";
import Navbar from './components/Navbar';
import Axios from 'axios';
import { doc, getDoc } from "firebase/firestore";
import {firestore,db} from './firebase'
import parse from 'html-react-parser';
import {useParams,BrowserRouter as Router , Routes,Route, Link} from "react-router-dom"
import QuePages from './components/QuePages';
import Index from './website freeb/Index';
import Quiz from './website freeb/Quiz';
import Easy from './website freeb/Easy';
import Medium from './website freeb/Medium';
import Hard from './website freeb/Hard';

function App() {

	const Code =()=>{
		const [data,setData]=useState({})
	const {id} =useParams()
	const [newAns,setAns]=useState(false)
// State variable to set users source code
const [userCode, setUserCode] = useState(``);

// State variable to set editors default language
const [userLang, setUserLang] = useState("python");

// State variable to set editors default theme
const [userTheme, setUserTheme] = useState("vs-dark");

// State variable to set editors default font size
const [fontSize, setFontSize] = useState(20);

// State variable to set users input
const [userInput, setUserInput] = useState("");

// State variable to set users output
const [userOutput, setUserOutput] = useState("");

// Loading state variable to show spinner
// while fetching data
const [loading, setLoading] = useState(false);

const getCode=async()=>{
	const docRef = doc(firestore,db.codes,id);
	const docSnap = await getDoc(docRef);
	setData(docSnap.data())
}

useEffect(()=>{
	getCode()
},[])

console.log(data)

const options = {
	fontSize: fontSize
}

// Function to call the compile endpoint
function compile() {
	setLoading(true);
	if (userCode === ``) {
	return
	}

	// Post request to compile endpoint
	Axios.post(`http://localhost:8000/compile`, {
	code: userCode,
	language: userLang,
	input: userInput }).then((res) => {
		console.log(res.data.output)
	setUserOutput(res.data.output);
	
	}).then(() => {
	setLoading(false);
	})
}

// Function to clear the output screen
function clearOutput() {
	setUserOutput("");
}
useEffect(()=>{
	if(userOutput==="5"){
		console.log("5")
		setAns(true)
	} 
	else setAns(false)
},[userOutput])


console.log( userOutput)

return (
	<div className="App">
	<Navbar
		userLang={userLang} setUserLang={setUserLang}
		userTheme={userTheme} setUserTheme={setUserTheme}
		fontSize={fontSize} setFontSize={setFontSize}
	/>
	<div className="main">
	<div className="right-container">
	
       { data.codeHtml&&parse(data?.codeHtml)}

		</div>
	<div className="left-container">
	<div>
		<Editor
			options={options}
			height="calc(100vh - 50px)"
			width="100%"
			theme={userTheme}
			language={userLang}
			defaultLanguage="python"
			defaultValue="# Enter your code here"
			onChange={(value) => { setUserCode(value) }}
		/>
		<div>{newAns&&<p>Success</p>}</div>
		<button className="run-btn" onClick={() => compile()}>
			Run
		</button>
		</div>
		
		<h4>Input:</h4>
		<div className="input-box">
			<textarea id="code-inp" onChange=
			{(e) => setUserInput(e.target.value)}>
			</textarea>
		</div>
		<h4>Output:</h4>
		{loading ? (
			<div className="spinner-box">
			{/* <img src={spinner} alt="Loading..." /> */}
			</div>
		) : (
			<div className="output-box">
			<pre>{parseInt(userOutput)?parseInt(userOutput):""}</pre>
			{userOutput&&<p>{parseInt(userOutput)===data?.ans?"sucesss":"Failed"}</p>}
			<button onClick={() => { clearOutput() }}
				className="clear-btn">
				Clear
			</button>
			</div>
		)}
	</div>
		
	</div>
	</div>
);
	}
	return(
	<Router>
		<Routes>
			<Route path='/' element={<Index/>}/>
			<Route path='/quiz' element={<Quiz/>}/>
			<Route path='codes/:id' element={<Code/>}/>
			<Route path='/Easy' element={<Easy/>}/>
			<Route path='/Medium' element={<Medium/>}/>
			<Route path='/Hard' element={<Hard/>}/>

		</Routes>
	</Router>
	)
	
	
}

export default App;
