import React, { useState } from 'react'
import './easy.css'
import { Link } from 'react-router-dom'
const QuePages = () => {

  const ans=0
 
  return (
    <main id="main">
  <section id="features" className="features">
    <div className="container">
      <div className="section-title">
        {/* <h2></h2> */}
        <h3>Eat - Sleep - Code -Repeat.</h3>
      </div>
      <div className="row">

        <Link to="/codes/palindrome"><div className="col-lg-3 col-md-4 col-6 col-6">
          <div className="icon-box">
            <i className="ri-store-line" style={{ color: "#ffbb2c" }} />
            <h3>
              
              <a href="">Palindrome Numbers </a>
            </h3>
          </div>
        </div></Link>

        <Link to="/codes/fibonacci"><div className="col-lg-3 col-md-4 col-6">
          <div className="icon-box">
            <i className="ri-bar-chart-box-line" style={{ color: "#5578ff" }} />
            <h3>
            <a href=""> Fibonacci Series</a>
            </h3>
          </div>
        </div></Link>

        <Link to="/codes/string_reversal"><div className="col-lg-3 col-md-4 col-6 mt-4 mt-md-0">
          <div className="icon-box">
            <i className="ri-calendar-todo-line" style={{ color: "#e80368" }} />
            <h3>
              <a href="">String Reversal</a>
            </h3>
          </div>
        </div></Link>

        <Link to="/codes/swapping"><div className="col-lg-3 col-md-4 col-6 mt-4 mt-lg-0">
          <div className="icon-box">
            <i className="ri-paint-brush-line" style={{ color: "#e361ff" }} />
            <h3>
              <a href="">Swapping Numbers</a>
            </h3>
          </div>
        </div></Link>


        <Link to="/codes/vowels_consonants"><div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-database-2-line" style={{ color: "#47aeff" }} />
            <h3>
           <a href="">Vowels And Consonants In A String</a>
            </h3>
          </div>
        </div></Link> 

       
        <Link to="/codes/prime_numbers"> <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-gradienter-line" style={{ color: "#ffa76e" }} />
            <h3>
              <a href="">Prime Numbers</a>
            </h3>
          </div>
        </div></Link>
        
        <Link to="/codes/Find_duplicates">  <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-file-list-3-line" style={{ color: "#11dbcf" }} />
            <h3>
              <a href="">Matching Elements In An Array</a>
            </h3>
          </div>
        </div></Link>
        <Link to="/codes/SumOfDigitsOfFiveDigitNumbers
">  <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-price-tag-2-line" style={{ color: "#4233ff" }} />
            <h3>
              <a href="">Sum Of Digits Of Five Digit Numbers</a>
            </h3>
          </div>
        </div></Link>
        <Link to="/codes/SearchInsertPositions">  <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-anchor-line" style={{ color: "#b2904f" }} />
            <h3>
              <a href="">Search Insert Positions</a>
            </h3>
          </div>
        </div></Link>

       
        
        <Link to="/codes/Sum_of_digits"> <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-base-station-line" style={{ color: "#ff5828" }} />
            <h3>
              <a href="">Sum Of Digits</a>
            </h3>
          </div>
        </div></Link>
        
        
        <Link to="/codes/Sum_of_unique_elements">  <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-fingerprint-line" style={{ color: "#29cc61" }} />
            <h3>
              <a href="">Sum Of Unique Elements</a>
            </h3>
          </div>
        </div></Link>
       
        <Link to="/codes/bitwise_operators">    <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-price-tag-2-line" style={{ color: "#4233ff" }} />
            <h3>
              <a href="">Bitwise Operators</a>
            </h3>
          </div>
        </div></Link>
                       
        <Link to="/codes/MergeTwoSortedLists">          
          <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-anchor-line" style={{ color: "#b2904f" }} />
            <h3>
              <a href="">Merge Two Sorted Lists</a>
            </h3>
          </div>
        </div></Link> 

        <Link to="/codes/Climbing_stairs">
          <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-disc-line" style={{ color: "#b20969" }} />
            <h3>
              <a href="">Climbing Stairs</a>
            </h3>
          </div>
        </div></Link>

        <Link to="/codes/BoxesThroughTunnel">
        <div className="col-lg-3 col-md-4 col-6 mt-4">
          <div className="icon-box">
            <i className="ri-anchor-line" style={{ color: "#b2904f" }} />
            <h3>
              <a href="">Boxes Through Tunnel</a>
            </h3>
          </div>
        </div></Link>
      </div>
    </div>
  </section>
</main>

  )
}

export default QuePages