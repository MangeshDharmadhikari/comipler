import { initializeApp } from "firebase/app"
// import "firebase/firebase-storage"
import { getFirestore, serverTimestamp } from "firebase/firestore";
import {getStorage} from 'firebase/storage'

const app = initializeApp({
    apiKey: "AIzaSyBhC5-V430glp60Ln6RKvkNIS4est4YMak",
    authDomain: "code-ladder-9d2ac.firebaseapp.com",
    projectId: "code-ladder-9d2ac",
    storageBucket: "code-ladder-9d2ac.appspot.com",
    messagingSenderId: "952762787466",
    appId: "1:952762787466:web:77ee4587aa5567eb7c2f73",
    measurementId: "G-ENBH9N4SGJ"
})


export const firestore = getFirestore(app);
export const db={
  codes:'codes',
  formatedDoc:doc=>{
    return{id:doc.id,...doc.data()}
  },
  getCurrentTimeStamp:serverTimestamp,
}
export default app;

