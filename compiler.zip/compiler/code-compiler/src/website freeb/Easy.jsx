import React from 'react'
import { Link } from 'react-router-dom'
import './css/easy.css'

const Easy = () => {
  return (
   <>
  <div>
  <main id="maineasy">
    <section id="features" className="features">
      <div className="container">
        <div className="section-title">
          {/* <h2></h2> */}
          <h3>Eat - Sleep - Code -Repeat.</h3>
        </div>
        <div className="row">
          <div className="col-lg-3 col-md-4 col-6 col-6">
            <div className="icon-box">
              <i className="ri-store-line" style={{color: '#ffbb2c'}} />
              <h3>
              <Link to={"/codes/BoxesThroughTunnel"} style={{textDecoration: 'none'}}>Boxes Through Tunnel</Link>
              
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6">
            <div className="icon-box">
              <i className="ri-bar-chart-box-line" style={{color: '#5578ff'}} />
              <h3><Link to={"/codes/Climbing_stairs"} style={{textDecoration: 'none'}}>Climbing stairs</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4 mt-md-0">
            <div className="icon-box">
              <i className="ri-calendar-todo-line" style={{color: '#e80368'}} />
              <h3>
              <Link to={"/codes/Find_duplicates"} style={{textDecoration: 'none'}}>Find Duplicates</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4 mt-lg-0">
            <div className="icon-box">
              <i className="ri-paint-brush-line" style={{color: '#e361ff'}} />
              <h3>
              <Link to={"/codes/MergeTwoSortedLists"} style={{textDecoration: 'none'}}>Merge Two Sorted Lists</Link>
                </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-database-2-line" style={{color: '#47aeff'}} />
              <h3><Link to={"/codes/SearchInsertPositions"} style={{textDecoration: 'none'}}>Search Insert Positions</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-gradienter-line" style={{color: '#ffa76e'}} />
              <h3>
              <Link to={"/codes/SumOfDigitsOfFiveDigitNumbers"} style={{textDecoration: 'none'}}>Sum of Digits of Five Digit Numbers</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-file-list-3-line" style={{color: '#11dbcf'}} />
              <h3>
              <Link to={"/codes/Sum_of_digits"} style={{textDecoration: 'none'}}>Sum of digits</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-price-tag-2-line" style={{color: '#4233ff'}} />
              <h3>
                <Link to={"/codes/Sum_of_unique_elements"} style={{textDecoration: 'none'}}>Sum of Unique Elements</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-anchor-line" style={{color: '#b2904f'}} />
              <h3><Link to={"/codes/bitwise_operators"} style={{textDecoration: 'none'}}>Bitwise Operators</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-disc-line" style={{color: '#b20969'}} />
              <h3><Link to={"/codes/factorial"} style={{textDecoration: 'none'}}>Factorial</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-base-station-line" style={{color: '#ff5828'}} />
              <h3><Link to={"/codes/fibonacci"} style={{textDecoration: 'none'}}>Fibonacci</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-fingerprint-line" style={{color: '#29cc61'}} />
              <h3>
                <Link to={"/codes/palindrome"} style={{textDecoration: 'none'}}>Palindrome</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-price-tag-2-line" style={{color: '#4233ff'}} />
              <h3>
                <Link to={"/codes/pointers"} style={{textDecoration: 'none'}}>Pointers</Link>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-anchor-line" style={{color: '#b2904f'}} />
              <h3><Link to={"/codes/prime_numbers"} style={{textDecoration: 'none'}}>Prime Numbers</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-disc-line" style={{color: '#b20969'}} />
              <h3><Link to={"/codes/string_reversal"} style={{textDecoration: 'none'}}>String Reversal</Link></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-anchor-line" style={{color: '#b2904f'}} />
              <h3><Link to={"/codes/swapping"} style={{textDecoration: 'none'}}>Swapping</Link></h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <a href="#" className="back-to-top d-flex align-items-center justify-content-center"><i className="bi bi-arrow-up-short" /></a>
</div>

   </>
  )
}

export default Easy