import React from 'react'
import { Link } from 'react-router-dom'
import './css/main.css'
import '../website freeb/assets/vendor/bootstrap/css/bootstrap.min.css'
import "../website freeb/assets/vendor/bootstrap-icons/bootstrap-icons.css"
import "../website freeb/assets/vendor/boxicons/css/boxicons.min.css"
import "../website freeb/assets/vendor/glightbox/css/glightbox.min.css"
import "../website freeb/assets/vendor/swiper/swiper-bundle.min.css"
import "../website freeb/assets/vendor/remixicon/remixicon.css"
const Index = () => {
  return (
    <>
   
  <div>
  <nav className="navbar navbar-expand-xl fixed-top">
    <div className="container">
      <a className="navbar-brand" href="./index.html"><img className="mt-5" src="img/rit.png" alt /></a>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <i className="fas fa-bars" />
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
          <li className="nav-item">
            <a className="nav-link  active" href="./index.html">Home</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#why-us">Why us</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#team">Team</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#contact">Contact</a>
          </li>         
        </ul>
      </div>
    </div>
  </nav>
  <main id="mainindex">
    {/* Intro */}
    <div className="container">
      <div className="intro pb-5">
        <div className="intro-text">
          <h1 className="intro-h1">Delivering successfull practice for placement !</h1>
          <p className="front-page" />
          <div className="buttons">
            <Link to="/Quiz" className="btn-fill">Quiz</Link>
            <Link to="/Quiz" className="btn-outline">Code</Link>
          </div>
        </div>
        <div className="intro-img">
          <img src="img/header-img.png" alt className="img-fluid" />
        </div>
      </div>
      {/* Clients */}
      <div className="clients text-center">
        <p className="text-muted text-uppercase pb-4">Some of our proud recruiters </p>
        <div className="client-logo">
          <div><img src="img/gupshup.png" alt /></div>
          <div><img src="img/kanaka.jpg" alt /></div>
          <div><img src="img/wipro.png" alt /></div>
          <div><img src="img/capgemini.png" alt /></div>
          <div><img src="img/kpit2.jpg" alt /></div>
        </div>
        <div className="client-logo">
          <div><img src="img/cognizant.jpg" alt /></div>
          <div><img src="img/tcs.jpg" alt /></div>
          <div><img src="img/brillio.png" alt /></div>
          <div><img src="img/KONE.jpg" alt /></div>
          <div><img src="img/gupshup.png" alt /></div>
        </div>
      </div>
      {/* Variations */}
      <section id="why-us" className="why-us">
        <div className="container" data-aos="fade-up">
          <div className="section-title">
            <h2>Why Us</h2>
            <p>Why Choose Our Website</p>
          </div>
          <div className="row">
            <div className="col-lg-4">
              <div className="box" data-aos="zoom-in" data-aos-delay={100}>
                <span>01</span>
                <h4>Secure</h4>
                <p>
                  System provides security to all users who use it and there is
                  no any illegal activity.<br />
                  Only the user can access his/her account ,no third person will
                  have access.
                </p>
              </div>
            </div>
            <div className="col-lg-4 mt-4 mt-lg-0">
              <div className="box" data-aos="zoom-in" data-aos-delay={200}>
                <span>02</span>
                <h4>Reliable</h4>
                <p>
                  The system is completely reliable.<br />
                  Authentication is required as per email verification.
                </p>
              </div>
            </div>
            <div className="col-lg-4 mt-4 mt-lg-0">
              <div className="box" data-aos="zoom-in" data-aos-delay={300}>
                <span>03</span>
                <h4>Proper Proctoring</h4>
                <p>
                  To avoid malpractice, we use the proctor method.<br />
                  Sending screenshots to an expert, screen sharing, split
                  screen, changing tabs etc is prohibited.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="service">
        <h1>Our placed students</h1>
        <p className="front-page" />
        <div className="service-items">
          <div className="item">
            <img src="img/icon/satisfied-client-icon.svg" alt />
            <span className="counter">890+</span>
            <span>Internships<br /></span>
          </div>
          <div className="item">
            <img src="img/mnc2.png" alt />
            <span className="counter">602+</span>
            <span>Company offers</span>
          </div>
          <div className="item">
            <img src="img/money.jpg" alt />
            <span className="counter">5.48 LPA</span>
            <span>Average Package</span>
          </div>
          <div className="item">
            <img src=".//img/tick2.png" alt />
            <span className="counter">92.7%</span>
            <span>Placement</span>
          </div>
        </div>
      </div>
      {/* Newsletter */}
      <div className="update-news">
        <div className="row">
          <div className="col-md-5 news-text">
            <h2>Get more update news</h2>
            <p>Start your journey with RIT and grab opportunity !!</p>
          </div>
          <div className="col-md-7 news-form">
            <a href="https://www.ritindia.edu/" target="_blank">
              <button>
                Click here to know more !!! 
              </button>
            </a>
          </div>
        </div>
      </div>
      {/* Team */}
      <section id="team">
        <div className="team text-center">
          <h1>Our Team</h1>
          <br /><br />
          {/* <p class="front-page">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p> */}
          <div className="team-person">
            <div className="person">
              {/* <div className="photo"><img src="img/team-1.png" alt /></div> */}
              <span className="name">Divya Patil</span>
              <span>Marketing Manager</span>
            </div>
            <div className="person">
              {/* <div className="photo"><img src="img/team-2.png" alt /></div> */}
              <span className="name">Mangesh Dharmadhikari</span>
              <span>SEO</span>
            </div>
            <div className="person">
              {/* <div className="photo"><img src="img/team-3.png" alt /></div> */}
              <span className="name">Shrutika Patil</span>
              <span>UI Expert</span>
            </div>
            <div className="person">
              {/* <div className="photo"><img src="img/team-4.png" alt /></div> */}
              <span className="name">Sagar Birajadar</span>
              <span>Web Developer</span>
            </div>
          </div>
        </div>
      </section></div>
  </main>
  <section>
    <section id="contact" className="contact">
      <div className="container" data-aos="fade-up">
        <div className="section-title">
          <h2>Contact</h2>
          <p>Contact Us</p>
        </div>
      </div>
      <div data-aos="fade-up">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3814.185760003694!2d74.283243!3d17.063564!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc174c4124484bd%3A0x35d1cbf0672b3f50!2sRajarambapu%20Institute%20of%20Technology!5e0!3m2!1sen!2sin!4v1659467697959!5m2!1sen!2sin" width="100%" height={450} style={{border: 0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
      </div>
      <div className="container" data-aos="fade-up">
        <div className="row mt-5">
          <div className="col-lg-4">
            <div className="info">
              <div className="address">
                <i className="bi bi-geo-alt" />
                <h4>Location:</h4>
                <p>
                  377M+C7H, Rajaramnagar, Uran Islampur, Maharashtra 415414,
                  India
                </p>
              </div>
              <div className="open-hours">
                <i className="bi bi-clock" />
                <h4>Open Hours:</h4>
                <p>
                  Monday-Saturday:<br />
                  10:00 AM - 1700 PM
                </p>
              </div>
              <div className="email">
                <i className="bi bi-envelope" />
                <h4>Email:</h4>
                <p>mangeshdharma713@gmail.com</p>
              </div>
              <div className="phone">
                <i className="bi bi-phone" />
                <h4>Call:</h4>
                <p>+91 77750 63846</p>
              </div>
            </div>
          </div>
          <div className="col-lg-8 mt-5 mt-lg-0">
            <form action="forms/contact.php" method="post" role="form" className="php-email-form">
              <div className="row">
                <div className="col-md-6 form-group">
                  <input type="text" name="name" className="form-control" id="name" placeholder="Your Name" required />
                </div>
                <div className="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" className="form-control" name="email" id="email" placeholder="Your Email" required />
                </div>
              </div>
              <div className="form-group mt-3">
                <input type="text" className="form-control" name="subject" id="subject" placeholder="Subject" required />
              </div>
              <div className="form-group mt-3">
                <textarea className="form-control" name="message" rows={8} placeholder="Message" required defaultValue={""} />
              </div>
              <div className="text-center" id="btn3">
                <button type="submit">Send Message</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </section>
  <div className="copyright">
    <p>© Created by CSIT, RIT</p>
  </div>
  {/* <div className="fb2022-copy">Fbee 2022 copyright</div> */}
</div>

    </>
  )
}

export default Index