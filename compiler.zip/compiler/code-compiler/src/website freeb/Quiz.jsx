import React  from 'react'
import  './css/quiz.css'
import { Link } from 'react-router-dom'

const Quiz = () => {

 

  return (
   <>
  <div>
  {/* ======= Header ======= */}
  <header id="header" className="fixed-top ">
    <div className="container d-flex align-items-center justify-content-between">
      <h1 className="logo"><a href="quiz.html" style={{color: '#FFF'}}>Code Ladder</a></h1>
    </div>
  </header>
  {/* End Header */}
  {/* ======= Hero Section ======= */}
  <section id="hero">
    <div className="hero-container">
      <h3>Welcome to <strong>Code Ladder</strong></h3>
      <h1>Code is like a humor.<br></br>When you have to explain it ,it's bad!</h1>
      {/* <h2>We are team of talented designers making websites </h2> */}
      <a href="#services" className="btn-get-started scrollto">Get Started</a>
    </div>
  </section>
  {/* End Hero */}
  <main id="mainquiz">
    {/* ======= Services Section ======= */}
    <section id="services" className="services">
      <div className="container">
        <div className="section-title">
          <h2>Services</h2>
          <h3>Prepare By Difficulty Levels <span>for placements</span></h3>
          <p>provide .</p>
        </div>
        <div className="row">
          <div className="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" style={{marginLeft : 220}}>
            <Link to='/Easy'>
            <div className="icon-box">
              <div className="icon"><i className="bx bxl-dribbble" /></div>
              <h4 className="title"> 
              <Link to="/Easy" style={{textDecoration: 'none'}}>Easy</Link> </h4>
              {/* <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p> */}
            </div>
            </Link>
          </div>
          <div className="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <Link to="/Medium">
            <div className="icon-box">
              <div className="icon"><i className="bx bx-file" /></div>
              <h4 className="title">
                <Link to="/Medium" style={{textDecoration: 'none'}}>Medium</Link>
              </h4>
              {/* <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p> */}
            </div>
            </Link>
           
          </div>
          <div className="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <Link to="/Hard">
            <div className="icon-box">
              <div className="icon"><i className="bx bx-tachometer" /></div>
              <h4 className="title">
                <Link to="/Hard" style={{textDecoration: 'none'}}>Hard</Link>
              </h4>
              {/* <p class="description">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p> */}
            </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
    {/* End Services Section */}
    {/* ======= Features Section ======= */}
    <section id="features" className="features">
      <div className="container">
        <div className="section-title">
          {/* <h2></h2> */}
          <h3>Prepare By Companies<span> for placements</span></h3>
          <p>provide .</p>
        </div>
        <div className="row">

                    
          <div className="col-lg-3 col-md-4 col-6 col-6">
            <div className="icon-box">
              <i className="ri-store-line" style={{color: '#e43c5c'}} />
             
              <a href={require('.//Document/TCS.pdf')} style={{textDecoration: 'none'}}  target="_blank">TCS</a>
              
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6">
            <div className="icon-box">
              <i className="ri-bar-chart-box-line" style={{color: '#5578ff'}} />
              
              <a href={require('.//Document/Cognizant.pdf')} style={{textDecoration: 'none'}} target="_blank">Cognizant</a>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4 mt-md-0">
            <div className="icon-box">
              <i className="ri-calendar-todo-line" style={{color: '#e80368'}} />
              <h3>
                
                <a href={require('.//Document/Accenture.pdf')} style={{textDecoration: 'none'}} target="_blank">Accenture</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4 mt-lg-0">
            <div className="icon-box">
              <i className="ri-paint-brush-line" style={{color: '#e361ff'}} />
              <h3>
                
                <a href={require('.//Document/Infosys.pdf')} style={{textDecoration: 'none'}} target="_blank">Infosys</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-database-2-line" style={{color: '#47aeff'}} />
             
              <a href={require('.//Document/Wipro.pdf')} style={{textDecoration: 'none'}} target="_blank">Wipro</a>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-gradienter-line" style={{color: '#ffa76e'}} />
              <h3>
               
                <a href={require('.//Document/capgi.pdf')} style={{textDecoration: 'none'}}  target="_blank">Capgemini</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-file-list-3-line" style={{color: '#11dbcf'}} />
              <h3>
              <a href={require('.//Document/TechMahindra.pdf')} style={{textDecoration: 'none'}}  target="_blank">Tech Mahindra</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-price-tag-2-line" style={{color: '#4233ff'}} />
              <h3>
              <a href={require('.//Document/IBM.pdf')} style={{textDecoration: 'none'}} target="_blank">IBM</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-anchor-line" style={{color: '#b2904f'}} />
              <h3>
              <a href={require('.//Document/Adobe.pdf')} style={{textDecoration: 'none'}} target="_blank">Adobe</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-disc-line" style={{color: '#b20969'}} />
              <h3>
              <a href={require('.//Document/L&T.pdf')} style={{textDecoration: 'none'}} target="_blank">L&T</a>
              </h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-base-station-line" style={{color: '#ff5828'}} />
              <h3><a href style={{textDecoration: 'none'}}>IBM</a></h3>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-6 mt-4">
            <div className="icon-box">
              <i className="ri-fingerprint-line" style={{color: '#29cc61'}} />
              <h3>
                <a href style={{textDecoration: 'none'}}>Wipro</a>
              </h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

   </>
  )
}

export default Quiz